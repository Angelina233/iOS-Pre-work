//
//  TipCalculatorViewController.swift
//  iOS Pre-work
//
//  Created by mac on 2021/1/13.
//


import UIKit

class TipCalculatorViewController: UIViewController
{
    
    @IBOutlet weak var amountBeforeTaxTextField: UITextField!
    @IBOutlet weak var tipPercentageLable: UILabel!
    @IBOutlet weak var tipPercentageSlider: UISlider!
    @IBOutlet weak var numberOfPeopleSlider: UISlider!
    @IBOutlet weak var numberOfPeopleLable: UILabel!
    
    @IBOutlet weak var eachPersonAmountLabel: UILabel!
    @IBOutlet weak var totalResultLable: UILabel!
    
    var tipCalculator = TipCalculator(amountBeforeTax: 0, tipPercentage: 0.10)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        amountBeforeTaxTextField.becomeFirstResponder()
    }
    
    func calculateBill(){
        tipCalculator.tipPercentage = Double(tipPercentageSlider.value) / 100.0
        tipCalculator.amountBeforeTax = (amountBeforeTaxTextField.text! as NSString).doubleValue
        tipCalculator.calculateTip()
        updateUI()
    }
    
    func updateUI() {
        totalResultLable.text = String(format: "$%0.2f", tipCalculator.totalAmount)
        let numberOfPeople: Int = Int(numberOfPeopleSlider.value)
        eachPersonAmountLabel.text = String(format: "$%0.2f", tipCalculator.totalAmount / Double(numberOfPeople))
    }
    
    
    
    // MARK: - Target / Action
    
    @IBAction func tipSliderValueChanged(sender:Any){
        tipPercentageLable.text = String(format: "Tip:%02d%%", Int(tipPercentageSlider.value))
        calculateBill()
    }
    
    @IBAction func numberOfPeopleSliderValueChanged(sender:Any){
        numberOfPeopleLable.text = "Slit: \(Int(numberOfPeopleSlider.value))"
        calculateBill()
    }
    
    @IBAction func amountBeforeTaxTextFieldChanged(sender:Any){
        calculateBill()
    }
}
